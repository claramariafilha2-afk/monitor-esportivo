# Monitor esportivo — versão inicial

Programa independente para consultar partidas **ao vivo** na API-Football, salvar snapshots JSON e opcionalmente enviar um resumo neutro de placares ao Telegram. Não cria sinais, entradas, probabilidades ou recomendações de apostas.

## Instalação

1. Instale Python 3.10 ou superior.
2. Extraia este ZIP para uma pasta.
3. Configure a variável de ambiente `API_FOOTBALL_KEY` com sua chave **no seu computador/servidor**; não envie a chave no chat.
4. Execute `python monitor.py` para uma consulta única.
5. Para execução contínua, defina `MODO_CONTINUO=1` e `INTERVALO_MINUTOS=10`, e execute `python monitor.py` em um computador ou servidor que permaneça ligado.
6. Opcional: configure `TELEGRAM_BOT_TOKEN` e `TELEGRAM_CHAT_ID` como variáveis de ambiente para receber um resumo a cada execução. Não compartilhe o token.

## Exemplo no PowerShell (Windows)

```powershell
$env:API_FOOTBALL_KEY = Read-Host 'Cole sua chave API-Football'
python monitor.py
```

## Limites e próximos passos

- O programa não está hospedado nem executando automaticamente após o download.
- A API-Football tem limites por plano. O intervalo de 10 minutos é apenas um padrão, não garantia de adequação ao seu plano.
- O endpoint `fixtures?live=all` retorna somente jogos ao vivo; jogos futuros exigem outra consulta.
- Os CSVs antigos não são necessários para rodar esta primeira versão. Podemos usá-los depois para auditoria de qualidade de dados.
- Não foram realizados testes com sua conta ou sua chave de API.
